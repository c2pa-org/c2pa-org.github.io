---
# Feel free to add content and custom Front Matter to this file.
# To modify the layout, see https://jekyllrb.com/docs/themes/#overriding-theme-defaults

layout: home
---
# Welcome

Welcome to the home of the Coalition for Content Provenance and Authenticity (CCPA).

## Background
stuff will go here...

**(more details to come)**

and more?
